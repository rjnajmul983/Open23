extends CharacterBody3D
class_name NexusVehicleController

## Smooth, Mobile-Optimized 3D Vehicle Physics & Animation Controller
## Supports all 6 vehicle models (Sedan, Sports, SUV, Pickup, Motorcycle, Police Interceptor)
## with wheel spin, front wheel steering, suspension body roll/pitch, siren flashers, engine pitch audio, and horn.

@export var vehicle_type: String = "sedan"
@export var max_speed: float = 28.0
@export var acceleration: float = 14.5
@export var brake_force: float = 24.0
@export var turn_speed: float = 2.15
@export var is_police: bool = false

var driver: Node3D = null
var current_speed: float = 0.0
var throttle_input: float = 0.0  # -1..+1
var steer_input: float = 0.0     # -1..+1
var handbrake: bool = false
var siren_active: bool = false

var model_root: Node3D
var wheels: Array[Node3D] = []
var front_wheels: Array[Node3D] = []
var engine_audio: AudioStreamPlayer3D
var siren_audio: AudioStreamPlayer3D
var _wheel_spin: float = 0.0


func setup_vehicle(glb_path: String, v_type: String) -> void:
	vehicle_type = v_type
	add_to_group("vehicles")
	collision_layer = 8
	collision_mask = 1 | 2 | 4 | 8

	match v_type:
		"sports":
			max_speed = 38.0; acceleration = 20.0; turn_speed = 2.45
		"motorcycle":
			max_speed = 35.0; acceleration = 22.0; turn_speed = 2.85
		"suv":
			max_speed = 25.0; acceleration = 12.0; turn_speed = 1.90
		"pickup":
			max_speed = 24.0; acceleration = 11.5; turn_speed = 1.85
		"police":
			max_speed = 34.0; acceleration = 18.0; turn_speed = 2.35; is_police = true
		_:
			max_speed = 28.0; acceleration = 14.5; turn_speed = 2.15

	# Collision box
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(0.8, 1.2, 2.2) if v_type == "motorcycle" else Vector3(2.0, 1.45, 4.5)
	col.shape = box
	col.position = Vector3(0, 0.85, 0)
	add_child(col)

	# Load 3D GLB model and cache separate wheel nodes for rotation/steering
	var res: PackedScene = load(glb_path)
	if res:
		model_root = res.instantiate()
		add_child(model_root)
		_collect_wheels(model_root)

	# Spatial engine loop audio
	engine_audio = AudioStreamPlayer3D.new()
	engine_audio.stream = AudioManager.get_stream("engine_loop")
	engine_audio.max_distance = 55.0
	engine_audio.volume_db = -12.0
	add_child(engine_audio)

	if is_police:
		siren_audio = AudioStreamPlayer3D.new()
		siren_audio.stream = AudioManager.get_stream("police_siren")
		siren_audio.max_distance = 90.0
		siren_audio.volume_db = -6.0
		add_child(siren_audio)

	GameManager.active_vehicles.append(self)


func _collect_wheels(node: Node) -> void:
	if node is Node3D and node.name.begins_with("Wheel"):
		wheels.append(node as Node3D)
		if node.name.contains("_F"):
			front_wheels.append(node as Node3D)
	for c in node.get_children():
		_collect_wheels(c)


func set_driver(new_driver: Node3D) -> void:
	driver = new_driver
	if driver != null:
		if engine_audio and engine_audio.stream and not engine_audio.playing:
			engine_audio.play()
		if is_police:
			set_siren(true)
	else:
		throttle_input = 0.0
		steer_input = 0.0
		if engine_audio and engine_audio.playing:
			engine_audio.stop()
		if is_police:
			set_siren(false)


func set_siren(active: bool) -> void:
	siren_active = active
	if siren_audio and siren_audio.stream:
		if active and not siren_audio.playing:
			siren_audio.play()
		elif not active and siren_audio.playing:
			siren_audio.stop()


func honk_horn() -> void:
	AudioManager.play_3d("horn", global_position, -2.0)


func _physics_process(delta: float) -> void:
	# Gravity
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	else:
		velocity.y = 0.0

	# Longitudinal acceleration / braking / drag
	if absf(throttle_input) > 0.05 and not handbrake:
		var accel := acceleration if (throttle_input * current_speed >= -0.5) else brake_force
		current_speed = clampf(current_speed + throttle_input * accel * delta, -max_speed * 0.38, max_speed)
	else:
		var drag := brake_force * 1.15 if handbrake else 5.5
		current_speed = move_toward(current_speed, 0.0, drag * delta)

	# Steering (scales smoothly with speed)
	if absf(current_speed) > 0.35:
		var steer_dir := 1.0 if current_speed >= 0.0 else -1.0
		var speed_factor := clampf(absf(current_speed) / 8.0, 0.2, 1.0)
		rotation.y -= steer_input * turn_speed * speed_factor * steer_dir * delta

	var fwd := global_basis.z
	velocity.x = fwd.x * current_speed
	velocity.z = fwd.z * current_speed

	var pre_spd := absf(current_speed)
	move_and_slide()

	# Collision speed damping
	if get_slide_collision_count() > 0 and pre_spd > 6.0:
		for i in range(get_slide_collision_count()):
			var col := get_slide_collision(i)
			if absf(col.get_normal().y) < 0.5:
				current_speed *= 0.45
				AudioManager.play_3d("brake_screech", global_position, -6.0)
				break

	# Animate wheels (spin + front steer) and suspension body roll/pitch
	_wheel_spin += (current_speed / 0.38) * delta
	for w in wheels:
		w.rotation.x = _wheel_spin
	for fw in front_wheels:
		fw.rotation.y = lerpf(fw.rotation.y, -steer_input * 0.48, minf(1.0, delta * 10.0))

	if model_root:
		var target_roll := steer_input * clampf(current_speed / max_speed, -1.0, 1.0) * (0.28 if vehicle_type == "motorcycle" else 0.055)
		var target_pitch := -throttle_input * 0.032
		model_root.rotation.z = lerpf(model_root.rotation.z, target_roll, minf(1.0, delta * 8.0))
		model_root.rotation.x = lerpf(model_root.rotation.x, target_pitch, minf(1.0, delta * 8.0))

	# Dynamic engine pitch
	if engine_audio and engine_audio.playing:
		engine_audio.pitch_scale = lerpf(0.85, 2.15, clampf(absf(current_speed) / max_speed, 0.0, 1.0))
