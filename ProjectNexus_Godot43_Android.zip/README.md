# PROJECT NEXUS — 3D Open-World Action-Adventure Android Game (Godot 4.3 Mobile)

Original third-person 3D open-world Android game engineered for a **100% phone-only workflow** using **Godot 4.3 Stable (Mobile Renderer)** and automated **GitHub Actions ARM64 APK compilation**.

## Architecture & Included Assets

- **6 Organic Sculpted, Rigged & Animated 3D Human Characters (`assets/characters/*.glb`)**:
  - `protagonist_kairo.glb` (Kairo Vance — male protagonist)
  - `npc_woman_elena.glb`, `npc_man_marcus.glb`, `npc_young_tara.glb`, `npc_elder_arthur.glb`, `npc_police_officer.glb`
  - Smooth anatomical lofted geometry (~3,130–3,250 vertices each, sculpted face/jaw/nose/lips/ears, individually modeled 5-finger hands, contoured footwear — zero cube/blocky humanoids).
  - Full 22-bone A-pose `Skeleton3D` with smooth multi-bone skin weights (`JOINTS_0`/`WEIGHTS_0`), embedded procedural PBR textures, and **30 embedded skeletal keyframe animations** (`Idle_Breathing`, `Walk`, `Jog`, `Run`, `Sprint`, `Jump_Start/Air/Fall/Land`, `Crouch_Idle/Walk`, `Combat_Punch/Kick/Block/Aim`, `Interact_Use`, `Phone_Use`, `Vehicle_Enter/Drive/Exit`, `Hit_React`, `Death`, `Talk_Gesture`, etc.).
- **6 Detailed 3D Vehicles (`assets/vehicles/*.glb`)**:
  - Sedan, Sports Car, SUV, Pickup Truck, Motorcycle, and Metro PD Interceptor with separate animated wheel nodes (`Wheel_FL/FR/RL/RR`), steering, suspension roll/pitch, siren flashers, horn, and dynamic engine audio.
- **Harborview & Downtown Nexus Open-World District (`assets/environment/*.glb` + `scripts/world/world_builder.gd`)**:
  - 4x4 chunk-streamed city grid (`360m x 360m`), asphalt roads, sidewalks, Central Nexus Park, residential apartments with balconies, commercial towers, shops, gas station, trees, benches, streetlights, and working traffic lights.
- **Complete Gameplay Systems (`scripts/`)**:
  - `AnimationTree` + `AnimationNodeStateMachine` + `BlendSpace1D` (`scripts/player/animation_controller.gd`)
  - Third-person mobile player controller (`scripts/player/player_controller.gd`)
  - Distance-activated Pedestrian AI, Traffic Light-obeying Road AI, and 5-Star Metro PD Pursuit System (`scripts/ai/`)
  - 3 Story Missions + repeatable Courier Side Missions with glowing 3D waypoint beacons (`scripts/missions/mission_manager.gd`)
  - Dynamic 24-hour Day/Night cycle & Clear/Overcast/Rain weather with GPU rain particles (`scripts/world/day_night_weather.gd`)
  - 12 synthesized original WAV sound effects (`assets/audio/*.wav`) + spatial `AudioManager`
  - JSON Save/Load (`user://project_nexus_save.json`) & Low/Medium/High Android graphics presets.

## Phone-Only Android APK Build (GitHub Actions)

1. Create or open a GitHub repository on your Android browser.
2. Upload **`ProjectNexus_Godot43_Android.zip`** directly to the repository root (no need to extract on your phone).
3. Create `.github/workflows/build-apk.yml` (copied from the workflow file inside the ZIP or provided alongside it) and commit.
4. Open the **Actions** tab → run **Build Project Nexus Android APK** → download **`ProjectNexus-ARM64-APK`** and install `ProjectNexus-arm64.apk` on your Android phone.
