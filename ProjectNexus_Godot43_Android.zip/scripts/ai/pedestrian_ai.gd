extends CharacterBody3D
class_name NexusPedestrianAI

## Distance-Activated Intelligent Human Pedestrian & Police Officer AI
## Uses real rigged GLB characters + NexusAnimationController for Walk, Idle, Talk, Flee, Combat & Death.

enum State { WALK, IDLE, TALK, FLEE, CHASE_PLAYER, DEAD }

var state: int = State.WALK
var is_police: bool = false
var health: float = 100.0
var walk_speed: float = 1.65
var run_speed: float = 5.4

var waypoints: Array[Vector3] = []
var wp_index: int = 0
var _state_timer: float = 0.0
var _attack_timer: float = 0.0

var model_root: Node3D
var anim_ctrl: NexusAnimationController


func setup_npc(glb_path: String, patrol_points: Array[Vector3], police_unit: bool = false) -> void:
	is_police = police_unit
	waypoints = patrol_points
	add_to_group("police" if is_police else "pedestrians")
	collision_layer = 4
	collision_mask = 1 | 2 | 4 | 8

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.30
	cap.height = 1.74
	col.shape = cap
	col.position = Vector3(0, 0.87, 0)
	add_child(col)

	var res := load(glb_path)
	if res:
		model_root = res.instantiate()
		add_child(model_root)
		anim_ctrl = NexusAnimationController.new()
		add_child(anim_ctrl)
		anim_ctrl.setup(model_root)

	walk_speed = randf_range(1.45, 2.05)
	if is_police:
		GameManager.active_police.append(self)
	else:
		GameManager.active_pedestrians.append(self)


func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		return

	# Distance-based AI activation for Android performance optimization
	var player := GameManager.player
	if player and is_instance_valid(player):
		var dist_p := global_position.distance_to(player.global_position)
		if dist_p > 125.0:
			visible = false
			return
		visible = true

		# Police pursue when Wanted Level > 0
		if is_police:
			if GameManager.wanted_level > 0 and dist_p < 85.0:
				state = State.CHASE_PLAYER
			elif state == State.CHASE_PLAYER and GameManager.wanted_level == 0:
				state = State.WALK
		else:
			# Civilians flee from active wanted combat nearby
			if GameManager.wanted_level >= 2 and dist_p < 18.0 and state != State.FLEE:
				state = State.FLEE
				_state_timer = 7.0

	if not is_on_floor():
		velocity.y -= 18.0 * delta

	match state:
		State.WALK:
			_tick_walk(delta)
		State.IDLE, State.TALK:
			_state_timer -= delta
			velocity.x = move_toward(velocity.x, 0.0, 12.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 12.0 * delta)
			if _state_timer <= 0.0:
				state = State.WALK
		State.FLEE:
			_tick_flee(delta)
		State.CHASE_PLAYER:
			_tick_police_chase(delta)

	move_and_slide()

	if anim_ctrl:
		var spd := Vector2(velocity.x, velocity.z).length()
		if state == State.TALK:
			anim_ctrl.trigger_action("Talk_Gesture", 0.3)
		else:
			anim_ctrl.update_movement(delta, clampf(spd / 7.5, 0.0, 1.0), is_on_floor(), velocity.y, false)


func _tick_walk(delta: float) -> void:
	if waypoints.is_empty():
		return
	var target := waypoints[wp_index]
	var to_t := target - global_position
	to_t.y = 0.0
	if to_t.length() < 1.6:
		wp_index = (wp_index + 1) % waypoints.size()
		if randf() < 0.28:
			state = State.TALK if randf() < 0.45 else State.IDLE
			_state_timer = randf_range(2.0, 5.0)
			return
	var dir := to_t.normalized()
	velocity.x = dir.x * walk_speed
	velocity.z = dir.z * walk_speed
	_face_dir(dir, delta)


func _tick_flee(delta: float) -> void:
	_state_timer -= delta
	if _state_timer <= 0.0 or GameManager.player == null:
		state = State.WALK
		return
	var away := global_position - GameManager.player.global_position
	away.y = 0.0
	if away.length_squared() < 0.01:
		away = Vector3.FORWARD
	var dir := away.normalized()
	velocity.x = dir.x * run_speed
	velocity.z = dir.z * run_speed
	_face_dir(dir, delta)


func _tick_police_chase(delta: float) -> void:
	var player := GameManager.player
	if player == null or not is_instance_valid(player):
		return
	var to_p := player.global_position - global_position
	to_p.y = 0.0
	var dist := to_p.length()
	var dir := to_p.normalized() if dist > 0.01 else Vector3.FORWARD
	_face_dir(dir, delta)

	_attack_timer = maxf(0.0, _attack_timer - delta)
	if dist > 2.1:
		velocity.x = dir.x * (run_speed + 0.6)
		velocity.z = dir.z * (run_speed + 0.6)
	else:
		velocity.x = 0.0
		velocity.z = 0.0
		if _attack_timer <= 0.0:
			_attack_timer = 1.25
			if anim_ctrl:
				anim_ctrl.trigger_action("Combat_Punch", 0.45)
			AudioManager.play_3d("punch_hit", global_position, -4.0)
			if player.has_method("take_damage"):
				player.take_damage(12.0, self)


func _face_dir(dir: Vector3, delta: float) -> void:
	if model_root and dir.length_squared() > 0.001:
		var yaw := atan2(dir.x, dir.z)
		model_root.rotation.y = lerp_angle(model_root.rotation.y, yaw, minf(1.0, delta * 8.0))


func take_damage(amount: float, _attacker: Node = null) -> void:
	if state == State.DEAD:
		return
	health -= amount
	if health <= 0.0:
		state = State.DEAD
		velocity = Vector3.ZERO
		set_collision_layer_value(3, false)
		if anim_ctrl:
			anim_ctrl.trigger_death()
		if is_police:
			GameManager.report_crime(3)
			GameManager.add_money(75)
	else:
		if anim_ctrl:
			anim_ctrl.trigger_action("Hit_React", 0.35)
		if not is_police:
			state = State.FLEE
			_state_timer = 10.0
		else:
			state = State.CHASE_PLAYER
