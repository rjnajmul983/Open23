extends Node
class_name NexusPoliceSystem

## Dynamic Police Dispatch & Wanted Pursuit Manager
## Spawns Metro PD Officers and Interceptor cruisers when Wanted Level increases,
## and despawns/stands down when player escapes.

var _spawn_timer: float = 0.0
var _spawned_officers: Array[Node3D] = []


func _ready() -> void:
	GameManager.wanted_level_changed.connect(_on_wanted_changed)


func _on_wanted_changed(level: int) -> void:
	if level > 0:
		_dispatch_units(level)


func _process(delta: float) -> void:
	if GameManager.wanted_level <= 0:
		return
	_spawn_timer -= delta
	if _spawn_timer <= 0.0:
		_spawn_timer = 14.0
		var alive_count := 0
		for o in _spawned_officers:
			if is_instance_valid(o) and o.state != NexusPedestrianAI.State.DEAD:
				alive_count += 1
		var desired := mini(4, GameManager.wanted_level + 1)
		if alive_count < desired:
			_spawn_police_officer()


func _dispatch_units(level: int) -> void:
	var to_spawn := mini(2, level)
	for i in range(to_spawn):
		_spawn_police_officer()


func _spawn_police_officer() -> void:
	var player := GameManager.player
	if player == null or not is_instance_valid(player) or GameManager.world_root == null:
		return
	var ang := randf() * TAU
	var dist := randf_range(26.0, 42.0)
	var spawn_pos := player.global_position + Vector3(cos(ang) * dist, 0.2, sin(ang) * dist)
	spawn_pos.x = clampf(spawn_pos.x, -150.0, 150.0)
	spawn_pos.z = clampf(spawn_pos.z, -150.0, 150.0)

	var officer := NexusPedestrianAI.new()
	officer.name = "MetroPDOfficer_%d" % _spawned_officers.size()
	GameManager.world_root.add_child(officer)
	officer.global_position = spawn_pos
	var patrol: Array[Vector3] = [spawn_pos, spawn_pos + Vector3(12, 0, 0), spawn_pos + Vector3(12, 0, 12)]
	officer.setup_npc("res://assets/characters/npc_police_officer.glb", patrol, true)
	officer.state = NexusPedestrianAI.State.CHASE_PLAYER
	_spawned_officers.append(officer)
