extends Node

## Modular Story & Side Mission Framework for Project Nexus
## Features 3 Story Missions + Repeatable Harborview Courier Side Missions with glowing 3D waypoint beacons.

signal mission_updated(title: String, objective: String, target_pos: Vector3)

var current_mission_index: int = 0
var completed_missions: Array = []
var active_target_pos: Vector3 = Vector3.ZERO
var has_active_mission: bool = false

var _beacon_mesh: MeshInstance3D = null

var STORY_MISSIONS: Array[Dictionary] = [
	{
		"id": "m1_first_contact",
		"title": "Mission 1: First Contact",
		"objective": "Head to Central Nexus Park and meet your fixer near the fountain.",
		"target": Vector3(0.0, 0.5, -52.0),
		"radius": 6.5,
		"reward": 350,
		"wanted_trigger": 0,
	},
	{
		"id": "m2_midnight_delivery",
		"title": "Mission 2: Harborview Run",
		"objective": "Grab a car and deliver the encrypted drive to the Gas Station.",
		"target": Vector3(68.0, 0.5, 58.0),
		"radius": 8.0,
		"reward": 750,
		"wanted_trigger": 1,
	},
	{
		"id": "m3_downtown_escape",
		"title": "Mission 3: Downtown Showdown",
		"objective": "Reach the Commercial Plaza rooftop drop zone & evade Metro PD!",
		"target": Vector3(-68.0, 0.5, -62.0),
		"radius": 8.0,
		"reward": 1500,
		"wanted_trigger": 2,
	},
]


func start_mission_system(world_root: Node3D) -> void:
	_create_beacon(world_root)
	_activate_mission(current_mission_index)


func _create_beacon(world_root: Node3D) -> void:
	_beacon_mesh = MeshInstance3D.new()
	_beacon_mesh.name = "MissionBeacon"
	var cyl := CylinderMesh.new()
	cyl.top_radius = 1.6
	cyl.bottom_radius = 1.6
	cyl.height = 18.0
	_beacon_mesh.mesh = cyl

	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.72, 0.12, 0.38)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.65, 0.08)
	mat.emission_energy_multiplier = 2.2
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_beacon_mesh.material_override = mat
	world_root.add_child(_beacon_mesh)


func _activate_mission(idx: int) -> void:
	has_active_mission = true
	if idx < STORY_MISSIONS.size():
		var m: Dictionary = STORY_MISSIONS[idx]
		active_target_pos = m["target"]
		if _beacon_mesh:
			_beacon_mesh.global_position = active_target_pos + Vector3(0, 9.0, 0)
			_beacon_mesh.visible = true
		mission_updated.emit(m["title"], m["objective"], active_target_pos)
		GameManager.post_notification(m["title"], m["objective"])
	else:
		# Repeatable Open-World Courier Side Mission
		var side_pts: Array[Vector3] = [
			Vector3(64.0, 0.5, -64.0),
			Vector3(-64.0, 0.5, 64.0),
			Vector3(0.0, 0.5, 76.0),
			Vector3(76.0, 0.5, 0.0),
		]
		active_target_pos = side_pts[idx % side_pts.size()]
		if _beacon_mesh:
			_beacon_mesh.global_position = active_target_pos + Vector3(0, 9.0, 0)
			_beacon_mesh.visible = true
		mission_updated.emit("Side Job: Express Courier", "Reach the glowing yellow drop zone for a $400 payout.", active_target_pos)


func _process(delta: float) -> void:
	if not has_active_mission or GameManager.player == null or not is_instance_valid(GameManager.player):
		return

	if _beacon_mesh and _beacon_mesh.visible:
		_beacon_mesh.rotate_y(delta * 1.4)

	var p_pos := GameManager.player.global_position
	var radius := 7.0
	if current_mission_index < STORY_MISSIONS.size():
		radius = float(STORY_MISSIONS[current_mission_index]["radius"])

	if Vector2(p_pos.x - active_target_pos.x, p_pos.z - active_target_pos.z).length() <= radius:
		_complete_current_mission()


func _complete_current_mission() -> void:
	AudioManager.play_ui("mission_complete", -2.0)
	if current_mission_index < STORY_MISSIONS.size():
		var m: Dictionary = STORY_MISSIONS[current_mission_index]
		completed_missions.append(m["id"])
		GameManager.add_money(int(m["reward"]))
		GameManager.respect += 100
		if int(m["wanted_trigger"]) > 0:
			GameManager.report_crime(int(m["wanted_trigger"]))
		GameManager.post_notification("MISSION PASSED! +$%d" % int(m["reward"]), m["title"] + " completed.")
	else:
		GameManager.add_money(400)
		GameManager.respect += 40
		GameManager.post_notification("COURIER COMPLETE! +$400", "Next drop zone marked on your minimap.")

	current_mission_index += 1
	_activate_mission(current_mission_index)


func try_interact(pos: Vector3) -> void:
	if pos.distance_to(active_target_pos) < 12.0:
		_complete_current_mission()


func restore_progress(idx: int, completed: Array) -> void:
	current_mission_index = maxi(0, idx)
	completed_missions = completed.duplicate()
	_activate_mission(current_mission_index)
