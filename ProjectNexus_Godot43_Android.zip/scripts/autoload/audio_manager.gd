extends Node

## Spatial & UI Audio Manager for Project Nexus
## Preloads all synthesized original WAV assets and manages pooled 2D/3D audio playback.

var _streams: Dictionary = {}
var _ambience_player: AudioStreamPlayer
var _rain_player: AudioStreamPlayer
var _ui_player: AudioStreamPlayer


func _ready() -> void:
	var sfx_names := [
		"footstep", "land", "engine_loop", "horn", "brake_screech",
		"punch_hit", "gunshot", "police_siren", "rain_loop",
		"city_ambience", "ui_click", "mission_complete"
	]
	for n in sfx_names:
		var path := "res://assets/audio/%s.wav" % n
		if ResourceLoader.exists(path):
			var st := load(path)
			if st is AudioStreamWAV and (n.ends_with("_loop") or n == "police_siren" or n == "city_ambience"):
				st.loop_mode = AudioStreamWAV.LOOP_FORWARD
				st.loop_end = int(st.get_length() * st.mix_rate)
			_streams[n] = st

	_ambience_player = AudioStreamPlayer.new()
	_ambience_player.volume_db = -14.0
	add_child(_ambience_player)
	if _streams.has("city_ambience"):
		_ambience_player.stream = _streams["city_ambience"]
		_ambience_player.play()

	_rain_player = AudioStreamPlayer.new()
	_rain_player.volume_db = -40.0
	add_child(_rain_player)
	if _streams.has("rain_loop"):
		_rain_player.stream = _streams["rain_loop"]

	_ui_player = AudioStreamPlayer.new()
	_ui_player.volume_db = -4.0
	add_child(_ui_player)


func get_stream(sfx_name: String) -> AudioStream:
	return _streams.get(sfx_name, null)


func play_ui(sfx_name: String, volume_db: float = -4.0) -> void:
	var st := get_stream(sfx_name)
	if st == null:
		return
	_ui_player.stream = st
	_ui_player.volume_db = volume_db
	_ui_player.play()


func play_3d(sfx_name: String, world_pos: Vector3, volume_db: float = -2.0, pitch: float = 1.0) -> void:
	var st := get_stream(sfx_name)
	if st == null:
		return
	var p := AudioStreamPlayer3D.new()
	p.stream = st
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.max_distance = 65.0
	p.unit_size = 6.0
	get_tree().root.add_child(p)
	p.global_position = world_pos
	p.finished.connect(p.queue_free)
	p.play()


func set_rain_intensity(intensity: float) -> void:
	if _rain_player == null or _rain_player.stream == null:
		return
	if intensity > 0.05:
		if not _rain_player.playing:
			_rain_player.play()
		_rain_player.volume_db = lerpf(-32.0, -8.0, clampf(intensity, 0.0, 1.0))
	else:
		if _rain_player.playing:
			_rain_player.stop()
