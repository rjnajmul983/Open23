extends Node
class_name NexusTrafficAI

## Autonomous Road Traffic AI Driver attached to a NexusVehicleController
## Follows road lane loops, stops at red traffic lights, maintains safe following distance,
## and yields immediately when the player hijacks/enters the vehicle.

var vehicle: NexusVehicleController
var route_points: Array[Vector3] = []
var point_idx: int = 0
var cruise_speed: float = 11.5
var _world_ref: Node = null


func setup_route(veh: NexusVehicleController, points: Array[Vector3], world_ref: Node) -> void:
	vehicle = veh
	route_points = points
	_world_ref = world_ref
	cruise_speed = randf_range(9.5, 13.5)


func _physics_process(_delta: float) -> void:
	if vehicle == null or not is_instance_valid(vehicle):
		return
	# Yield control immediately if the player is driving this vehicle
	if vehicle.driver != null:
		return
	if route_points.is_empty():
		return

	var target := route_points[point_idx]
	var to_t := target - vehicle.global_position
	to_t.y = 0.0
	if to_t.length() < 4.5:
		point_idx = (point_idx + 1) % route_points.size()
		target = route_points[point_idx]
		to_t = target - vehicle.global_position
		to_t.y = 0.0

	var dir := to_t.normalized()
	var fwd := vehicle.global_basis.z
	var right := vehicle.global_basis.x
	var cross_dot := right.dot(dir)
	var steer := clampf(cross_dot * 2.2, -1.0, 1.0)

	# Obstacle / safe following distance check
	var should_stop := false
	for other in GameManager.active_vehicles:
		if other == vehicle or not is_instance_valid(other):
			continue
		var diff := other.global_position - vehicle.global_position
		if diff.length() < 9.5 and diff.normalized().dot(fwd) > 0.72:
			should_stop = true
			break

	# Check player in front of car
	if not should_stop and GameManager.player and is_instance_valid(GameManager.player) and not GameManager.player.is_in_vehicle:
		var pd := GameManager.player.global_position - vehicle.global_position
		if pd.length() < 8.5 and pd.normalized().dot(fwd) > 0.65:
			should_stop = true

	# Obey global intersection traffic light phase when approaching an intersection
	if not should_stop and _world_ref and _world_ref.has_method("is_red_light_for"):
		if _world_ref.is_red_light_for(vehicle.global_position, fwd):
			should_stop = true

	vehicle.steer_input = steer
	if should_stop:
		vehicle.throttle_input = 0.0
		vehicle.handbrake = true
	else:
		vehicle.handbrake = false
		if vehicle.current_speed < cruise_speed * (1.0 - absf(steer) * 0.4):
			vehicle.throttle_input = 0.65
		else:
			vehicle.throttle_input = 0.0
