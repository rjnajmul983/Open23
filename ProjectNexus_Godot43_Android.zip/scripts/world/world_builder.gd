extends Node3D
class_name NexusWorldBuilder

## Harborview & Downtown Nexus — Playable 3D Open-World District Builder & Chunk Streamer
## Constructs a 360m x 360m living city with 4-lane roads, crosswalks, sidewalks,
## Central Nexus Park, waterfront bridge, architectural buildings, traffic lights,
## 6 drivable 3D vehicles, intelligent pedestrians, autonomous traffic, and chunk culling.

const BLOCK_STEP := 64.0
const ROAD_WIDTH := 14.0
const CHUNK_RADIUS := 175.0

var chunks: Array[Node3D] = []
var day_night: NexusDayNightWeather
var police_sys: NexusPoliceSystem
var hud: CanvasLayer

var _traffic_light_timer: float = 0.0
var _ns_green: bool = true  # North-South green vs East-West green


func _ready() -> void:
	GameManager.world_root = self
	GameManager.active_vehicles.clear()
	GameManager.active_pedestrians.clear()
	GameManager.active_police.clear()

	# 1. Day/Night & Weather System
	day_night = NexusDayNightWeather.new()
	day_night.name = "DayNightWeather"
	add_child(day_night)

	# 2. Police & Wanted System
	police_sys = NexusPoliceSystem.new()
	police_sys.name = "PoliceSystem"
	add_child(police_sys)

	# 3. Build Ground, Roads, Crosswalks & Sidewalks
	_build_ground_and_roads()

	# 4. Build Chunked Architectural City Blocks (Residential, Commercial, Shops, Gas Station, Park)
	_build_city_chunks()

	# 5. Spawn Main Protagonist (Kairo Vance)
	var player := NexusPlayerController.new()
	player.name = "Player_KairoVance"
	add_child(player)
	player.global_position = Vector3(11.0, 0.5, 14.0)

	# 6. Spawn All 6 Drivable Vehicles + Autonomous Traffic AI
	_spawn_vehicles_and_traffic()

	# 7. Spawn Diverse Animated Pedestrians (Elena, Marcus, Tara, Arthur + Patrol Officer)
	_spawn_pedestrians()

	# 8. Start Mission & Story System
	MissionManager.start_mission_system(self)

	# 9. Attach Responsive Mobile Touch HUD
	var hud_script: GDScript = load("res://scripts/ui/mobile_hud.gd")
	if hud_script:
		hud = hud_script.new()
		hud.name = "MobileHUD"
		add_child(hud)
		if hud.has_method("bind_world"):
			hud.bind_world(player, day_night)


func _process(delta: float) -> void:
	# Traffic light 12-second phase alternation
	_traffic_light_timer += delta
	if _traffic_light_timer >= 12.0:
		_traffic_light_timer = 0.0
		_ns_green = not _ns_green

	# Chunk-based visibility culling around player for stable 30-60 FPS on Android
	var p := GameManager.player
	if p and is_instance_valid(p):
		var px := p.global_position.x
		var pz := p.global_position.z
		for ch in chunks:
			var dx := ch.position.x - px
			var dz := ch.position.z - pz
			ch.visible = (dx * dx + dz * dz) <= (CHUNK_RADIUS * CHUNK_RADIUS)


func is_red_light_for(pos: Vector3, fwd: Vector3) -> bool:
	# Check if vehicle is approaching any grid intersection (multiples of 64m)
	var gx := roundf(pos.x / BLOCK_STEP) * BLOCK_STEP
	var gz := roundf(pos.z / BLOCK_STEP) * BLOCK_STEP
	var d := Vector2(pos.x - gx, pos.z - gz).length()
	if d > 8.0 and d < 16.0:
		var moving_ns := absf(fwd.z) > absf(fwd.x)
		return (moving_ns and not _ns_green) or ((not moving_ns) and _ns_green)
	return false


func _build_ground_and_roads() -> void:
	# Master ground plane collider + grass/concrete base
	var ground := StaticBody3D.new()
	ground.name = "WorldGround"
	ground.collision_layer = 1
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(420.0, 1.0, 420.0)
	col.shape = box
	col.position = Vector3(0, -0.5, 0)
	ground.add_child(col)

	var base_mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(420.0, 420.0)
	base_mesh.mesh = plane
	var base_mat := StandardMaterial3D.new()
	base_mat.albedo_color = Color(0.56, 0.57, 0.55)  # Sidewalk concrete tone
	base_mat.roughness = 0.88
	base_mesh.material_override = base_mat
	ground.add_child(base_mesh)
	add_child(ground)

	# Asphalt Road Grid along X and Z at -128, -64, 0, +64, +128
	var asphalt_mat := StandardMaterial3D.new()
	asphalt_mat.albedo_color = Color(0.14, 0.15, 0.17)
	asphalt_mat.roughness = 0.82

	var line_mat := StandardMaterial3D.new()
	line_mat.albedo_color = Color(0.92, 0.78, 0.22)
	line_mat.roughness = 0.65

	var road_coords: Array[float] = [-128.0, -64.0, 0.0, 64.0, 128.0]
	for rc in road_coords:
		# Road along Z
		_add_flat_strip(Vector3(rc, 0.02, 0.0), Vector2(ROAD_WIDTH, 320.0), asphalt_mat)
		_add_flat_strip(Vector3(rc, 0.03, 0.0), Vector2(0.28, 320.0), line_mat)
		# Road along X
		_add_flat_strip(Vector3(0.0, 0.025, rc), Vector2(320.0, ROAD_WIDTH), asphalt_mat)
		_add_flat_strip(Vector3(0.0, 0.032, rc), Vector2(320.0, 0.28), line_mat)

	# Waterfront Harbor strip on South edge (+168m) with decorative bridge deck
	var water_mat := StandardMaterial3D.new()
	water_mat.albedo_color = Color(0.08, 0.28, 0.44)
	water_mat.metallic = 0.35
	water_mat.roughness = 0.18
	_add_flat_strip(Vector3(0.0, 0.01, 182.0), Vector2(420.0, 48.0), water_mat)


func _add_flat_strip(pos: Vector3, sz: Vector2, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = sz
	mi.mesh = pm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)


func _build_city_chunks() -> void:
	var res_apt: PackedScene = load("res://assets/environment/bldg_apartment.glb")
	var res_com: PackedScene = load("res://assets/environment/bldg_commercial.glb")
	var res_shp: PackedScene = load("res://assets/environment/bldg_shop.glb")
	var res_gas: PackedScene = load("res://assets/environment/bldg_gas_station.glb")
	var res_tree: PackedScene = load("res://assets/environment/prop_tree.glb")
	var res_lamp: PackedScene = load("res://assets/environment/prop_streetlight.glb")
	var res_sig: PackedScene = load("res://assets/environment/prop_traffic_light.glb")
	var res_bench: PackedScene = load("res://assets/environment/prop_bench.glb")

	var grass_mat := StandardMaterial3D.new()
	grass_mat.albedo_color = Color(0.20, 0.42, 0.19)
	grass_mat.roughness = 0.92

	# 4x4 grid of city blocks centered at (-96, -32, +32, +96)
	var centers: Array[float] = [-96.0, -32.0, 32.0, 96.0]
	for bx in range(4):
		for bz in range(4):
			var cx: float = centers[bx]
			var cz: float = centers[bz]
			var chunk := Node3D.new()
			chunk.name = "CityChunk_%d_%d" % [bx, bz]
			chunk.position = Vector3(cx, 0.0, cz)
			add_child(chunk)
			chunks.append(chunk)

			# Central Nexus Park at block (1, 0) / (2, 0) near (0, -32)
			if bx == 1 and bz == 1:
				# Park lawn + trees + benches + central fountain
				var lawn := MeshInstance3D.new()
				var lp := PlaneMesh.new()
				lp.size = Vector2(46.0, 46.0)
				lawn.mesh = lp
				lawn.material_override = grass_mat
				lawn.position = Vector3(0, 0.04, 0)
				chunk.add_child(lawn)

				for tx in [-16.0, -6.0, 8.0, 16.0]:
					for tz in [-15.0, 15.0]:
						_place_prop(chunk, res_tree, Vector3(tx, 0, tz), randf() * TAU)
				_place_prop(chunk, res_bench, Vector3(-6.0, 0, -4.0), 0.0)
				_place_prop(chunk, res_bench, Vector3(6.0, 0, 4.0), PI)
			elif bx == 2 and bz == 2:
				# Harborview Gas Station + Corner Shop
				_place_building(chunk, res_gas, Vector3(0.0, 0.0, 4.0), 0.0, Vector3(16.0, 6.0, 12.0))
				_place_building(chunk, res_shp, Vector3(-14.0, 0.0, -14.0), PI * 0.5, Vector3(14.0, 9.0, 11.0))
			else:
				# Mixed Downtown Commercial Towers, Residential Apartments & Street-Level Shops
				var pat := (bx * 3 + bz) % 3
				if pat == 0:
					_place_building(chunk, res_com, Vector3(-10.0, 0, -10.0), 0.0, Vector3(18.0, 36.0, 16.0))
					_place_building(chunk, res_apt, Vector3(11.0, 0, 10.0), PI, Vector3(16.0, 22.0, 14.0))
				elif pat == 1:
					_place_building(chunk, res_apt, Vector3(-10.0, 0, 10.0), PI * 0.5, Vector3(16.0, 22.0, 14.0))
					_place_building(chunk, res_shp, Vector3(11.0, 0, -11.0), 0.0, Vector3(14.0, 9.0, 11.0))
				else:
					_place_building(chunk, res_com, Vector3(10.0, 0, -10.0), -PI * 0.5, Vector3(18.0, 36.0, 16.0))
					_place_building(chunk, res_shp, Vector3(-11.0, 0, 11.0), PI, Vector3(14.0, 9.0, 11.0))

				# Street trees along sidewalks
				_place_prop(chunk, res_tree, Vector3(-21.0, 0, 0.0), 0.0)
				_place_prop(chunk, res_tree, Vector3(21.0, 0, 0.0), 1.5)

			# Streetlights & Traffic Lights at block corners
			_place_prop(chunk, res_lamp, Vector3(-23.0, 0, -23.0), PI * 0.25)
			_place_prop(chunk, res_lamp, Vector3(23.0, 0, 23.0), -PI * 0.75)
			if bx in [1, 2] and bz in [1, 2]:
				_place_prop(chunk, res_sig, Vector3(-24.0, 0, 24.0), PI * 0.5)


func _place_building(parent: Node3D, res: PackedScene, pos: Vector3, rot_y: float, col_size: Vector3) -> void:
	if res == null:
		return
	var sb := StaticBody3D.new()
	sb.collision_layer = 1
	sb.position = pos
	sb.rotation.y = rot_y
	var inst: Node = res.instantiate()
	sb.add_child(inst)
	var cs := CollisionShape3D.new()
	var bx := BoxShape3D.new()
	bx.size = col_size
	cs.shape = bx
	cs.position = Vector3(0, col_size.y * 0.5, 0)
	sb.add_child(cs)
	parent.add_child(sb)


func _place_prop(parent: Node3D, res: PackedScene, pos: Vector3, rot_y: float) -> void:
	if res == null:
		return
	var inst: Node = res.instantiate() as Node3D
	inst.position = pos
	inst.rotation.y = rot_y
	parent.add_child(inst)


func _spawn_vehicles_and_traffic() -> void:
	# Parked hero vehicles right near spawn so player can test all 6 vehicle classes immediately
	var parked := [
		["res://assets/vehicles/vehicle_sports.glb",     "sports",     Vector3(6.0, 0.2, 18.0),   0.0],
		["res://assets/vehicles/vehicle_sedan.glb",      "sedan",      Vector3(-6.0, 0.2, 22.0),  PI],
		["res://assets/vehicles/vehicle_motorcycle.glb", "motorcycle", Vector3(13.0, 0.2, 8.0),   0.4],
		["res://assets/vehicles/vehicle_suv.glb",        "suv",        Vector3(24.0, 0.2, -6.0),  PI * 0.5],
		["res://assets/vehicles/vehicle_pickup.glb",     "pickup",     Vector3(64.0, 0.2, 48.0),  0.0],
		["res://assets/vehicles/vehicle_police.glb",     "police",     Vector3(-64.0, 0.2, 10.0), 0.0],
	]
	for p in parked:
		var v := NexusVehicleController.new()
		v.name = "Vehicle_%s" % p[1]
		add_child(v)
		v.global_position = p[2]
		v.rotation.y = p[3]
		v.setup_vehicle(p[0], p[1])

	# Autonomous AI Traffic Cars looping around Downtown Nexus avenues
	var loop_outer: Array[Vector3] = [
		Vector3(64.0, 0.2, -64.0), Vector3(64.0, 0.2, 64.0),
		Vector3(-64.0, 0.2, 64.0), Vector3(-64.0, 0.2, -64.0)
	]
	var loop_inner: Array[Vector3] = [
		Vector3(3.5, 0.2, -64.0), Vector3(3.5, 0.2, 64.0),
		Vector3(-64.0, 0.2, 64.0), Vector3(-64.0, 0.2, -64.0)
	]
	var traffic_specs := [
		["res://assets/vehicles/vehicle_sedan.glb",  "sedan",  Vector3(64.0, 0.2, -20.0), loop_outer],
		["res://assets/vehicles/vehicle_suv.glb",    "suv",    Vector3(-64.0, 0.2, 25.0), loop_outer],
		["res://assets/vehicles/vehicle_pickup.glb", "pickup", Vector3(3.5, 0.2, -32.0),  loop_inner],
		["res://assets/vehicles/vehicle_police.glb", "police", Vector3(-30.0, 0.2, 64.0), loop_outer],
	]
	for i in range(traffic_specs.size()):
		var ts = traffic_specs[i]
		var tv := NexusVehicleController.new()
		tv.name = "TrafficVehicle_%d" % i
		add_child(tv)
		tv.global_position = ts[2]
		tv.setup_vehicle(ts[0], ts[1])
		var ai := NexusTrafficAI.new()
		tv.add_child(ai)
		ai.setup_route(tv, ts[3], self)


func _spawn_pedestrians() -> void:
	var npc_models: Array[String] = [
		"res://assets/characters/npc_woman_elena.glb",
		"res://assets/characters/npc_man_marcus.glb",
		"res://assets/characters/npc_young_tara.glb",
		"res://assets/characters/npc_elder_arthur.glb",
	]
	var sidewalk_loops := [
		[Vector3(10.0, 0.2, 10.0), Vector3(10.0, 0.2, 54.0), Vector3(54.0, 0.2, 54.0), Vector3(54.0, 0.2, 10.0)],
		[Vector3(-10.0, 0.2, -10.0), Vector3(-54.0, 0.2, -10.0), Vector3(-54.0, 0.2, -54.0), Vector3(-10.0, 0.2, -54.0)],
		[Vector3(10.0, 0.2, -10.0), Vector3(54.0, 0.2, -10.0), Vector3(54.0, 0.2, -54.0), Vector3(10.0, 0.2, -54.0)],
		[Vector3(-10.0, 0.2, 10.0), Vector3(-10.0, 0.2, 54.0), Vector3(-54.0, 0.2, 54.0), Vector3(-54.0, 0.2, 10.0)],
	]

	for i in range(12):
		var npc := NexusPedestrianAI.new()
		npc.name = "Pedestrian_%d" % i
		add_child(npc)
		var loop: Array = sidewalk_loops[i % sidewalk_loops.size()]
		var pts: Array[Vector3] = []
		for pt in loop:
			pts.append(pt as Vector3)
		npc.global_position = pts[i % pts.size()] + Vector3(randf_range(-1.2, 1.2), 0.0, randf_range(-1.2, 1.2))
		npc.setup_npc(npc_models[i % npc_models.size()], pts, false)

	# 2 Beat Patrol Police Officers
	for j in range(2):
		var cop := NexusPedestrianAI.new()
		cop.name = "PatrolOfficer_%d" % j
		add_child(cop)
		var pts_c: Array[Vector3] = [Vector3(-12.0, 0.2, 12.0 + j * 25.0), Vector3(-12.0, 0.2, -45.0), Vector3(12.0, 0.2, -45.0)]
		cop.global_position = pts_c[0]
		cop.setup_npc("res://assets/characters/npc_police_officer.glb", pts_c, true)
