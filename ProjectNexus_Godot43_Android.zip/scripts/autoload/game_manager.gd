extends Node

## Global Game State, Economy, Wanted System Coordination & Graphics Quality Manager

signal money_changed(new_money: int)
signal wanted_level_changed(new_level: int)
signal health_changed(current: float, max_hp: float)
signal notification_posted(title: String, message: String)
signal vehicle_state_changed(in_vehicle: bool, vehicle_ref: Node)
signal graphics_quality_changed(level: int)

enum GraphicsQuality { LOW = 0, MEDIUM = 1, HIGH = 2 }

var player: Node3D = null
var current_vehicle: Node3D = null
var world_root: Node3D = null

var money: int = 500
var respect: int = 0
var wanted_level: int = 0
var wanted_decay_timer: float = 0.0
var time_of_day: float = 10.5  # 24-hour clock (starts 10:30 AM)
var weather_mode: String = "Clear"
var graphics_quality: int = GraphicsQuality.MEDIUM

# Registry for minimap & AI queries
var active_vehicles: Array[Node3D] = []
var active_pedestrians: Array[Node3D] = []
var active_police: Array[Node3D] = []


func _process(delta: float) -> void:
	if wanted_level > 0:
		wanted_decay_timer -= delta
		if wanted_decay_timer <= 0.0:
			set_wanted_level(wanted_level - 1)
			wanted_decay_timer = 18.0


func add_money(amount: int) -> void:
	money = maxi(0, money + amount)
	money_changed.emit(money)


func set_wanted_level(level: int) -> void:
	var clamped := clampi(level, 0, 5)
	if clamped != wanted_level:
		wanted_level = clamped
		wanted_level_changed.emit(wanted_level)
		if wanted_level > 0:
			wanted_decay_timer = 24.0 + wanted_level * 6.0
			post_notification("WANTED LEVEL %d" % wanted_level, "Metro PD has been alerted. Evade pursuit!")
		else:
			post_notification("WANTED CLEARED", "You escaped Metro PD pursuit.")


func report_crime(severity: int = 1) -> void:
	set_wanted_level(maxi(wanted_level, severity))
	wanted_decay_timer = 25.0 + wanted_level * 5.0


func post_notification(title: String, message: String) -> void:
	notification_posted.emit(title, message)


func set_graphics_quality(level: int) -> void:
	graphics_quality = clampi(level, 0, 2)
	var vp := get_viewport()
	if vp:
		match graphics_quality:
			GraphicsQuality.LOW:
				vp.scaling_3d_scale = 0.70
				vp.msaa_3d = Viewport.MSAA_DISABLED
			GraphicsQuality.MEDIUM:
				vp.scaling_3d_scale = 0.85
				vp.msaa_3d = Viewport.MSAA_2X
			GraphicsQuality.HIGH:
				vp.scaling_3d_scale = 1.00
				vp.msaa_3d = Viewport.MSAA_4X
	graphics_quality_changed.emit(graphics_quality)
