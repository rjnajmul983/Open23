extends Node3D
class_name NexusDayNightWeather

## Dynamic 24-Hour Day/Night Cycle & Weather System (Clear / Overcast / Rain)
## Drives DirectionalLight3D sun/moon, ProceduralSkyMaterial, ambient light, and GPU rain particles.

@export var day_speed_hours_per_sec: float = 0.08

var sun_light: DirectionalLight3D
var world_env: WorldEnvironment
var sky_mat: ProceduralSkyMaterial
var rain_particles: GPUParticles3D
var weather_timer: float = 45.0


func _ready() -> void:
	# Directional Sun / Moon Light
	sun_light = DirectionalLight3D.new()
	sun_light.shadow_enabled = true
	sun_light.directional_shadow_max_distance = 110.0
	add_child(sun_light)

	# Procedural Sky & Environment
	world_env = WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.fog_enabled = true
	env.fog_light_color = Color(0.68, 0.76, 0.86)
	env.fog_density = 0.0022
	world_env.environment = env
	add_child(world_env)

	# Mobile-friendly GPU Rain Particle System attached to player vicinity
	rain_particles = GPUParticles3D.new()
	rain_particles.amount = 650
	rain_particles.lifetime = 0.9
	rain_particles.emitting = false
	var pmat := ParticleProcessMaterial.new()
	pmat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pmat.emission_box_extents = Vector3(18.0, 1.0, 18.0)
	pmat.direction = Vector3(0.08, -1.0, 0.04)
	pmat.initial_velocity_min = 18.0
	pmat.initial_velocity_max = 24.0
	pmat.gravity = Vector3(0, -12, 0)
	rain_particles.process_material = pmat

	var drop := BoxMesh.new()
	drop.size = Vector3(0.025, 0.45, 0.025)
	var dmat := StandardMaterial3D.new()
	dmat.albedo_color = Color(0.75, 0.85, 0.96, 0.45)
	dmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	drop.material = dmat
	rain_particles.draw_pass_1 = drop
	add_child(rain_particles)


func _process(delta: float) -> void:
	GameManager.time_of_day = fmod(GameManager.time_of_day + day_speed_hours_per_sec * delta, 24.0)
	_update_lighting()

	# Keep rain box centered above player
	if GameManager.player and is_instance_valid(GameManager.player):
		rain_particles.global_position = GameManager.player.global_position + Vector3(0, 16.0, 0)

	# Periodic dynamic weather shift
	weather_timer -= delta
	if weather_timer <= 0.0:
		weather_timer = randf_range(50.0, 85.0)
		var modes: Array[String] = ["Clear", "Clear", "Overcast", "Rain"]
		set_weather(modes[randi() % modes.size()])


func set_weather(mode: String) -> void:
	GameManager.weather_mode = mode
	var is_rain := (mode == "Rain")
	rain_particles.emitting = is_rain
	AudioManager.set_rain_intensity(0.85 if is_rain else 0.0)
	if world_env and world_env.environment:
		world_env.environment.fog_density = 0.0055 if is_rain else (0.0035 if mode == "Overcast" else 0.0018)


func _update_lighting() -> void:
	var hr := GameManager.time_of_day
	# Sun elevation: 6:00 sunrise (0 deg), 12:00 noon (75 deg), 18:00 sunset (0 deg)
	var sun_angle := ((hr - 6.0) / 12.0) * PI
	var elev := sin(sun_angle)
	sun_light.rotation.x = -clampf(elev * 1.25, 0.15, 1.35)
	sun_light.rotation.y = ((hr / 24.0) * TAU) + 0.5

	var day_factor := clampf((elev + 0.15) / 0.65, 0.0, 1.0)
	var rain_dim := 0.65 if GameManager.weather_mode == "Rain" else (0.82 if GameManager.weather_mode == "Overcast" else 1.0)

	sun_light.light_energy = lerpf(0.18, 1.45, day_factor) * rain_dim
	sun_light.light_color = Color(0.45, 0.58, 0.85).lerp(Color(1.0, 0.94, 0.86), day_factor)

	# Golden hour tint near sunrise/sunset
	if absf(elev) < 0.25:
		sun_light.light_color = Color(1.0, 0.62, 0.34)

	sky_mat.sky_top_color = Color(0.04, 0.07, 0.16).lerp(Color(0.24, 0.52, 0.88), day_factor) * rain_dim
	sky_mat.sky_horizon_color = Color(0.10, 0.14, 0.24).lerp(Color(0.68, 0.79, 0.90), day_factor) * rain_dim
	world_env.environment.ambient_light_energy = lerpf(0.28, 0.85, day_factor) * rain_dim
