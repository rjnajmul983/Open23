extends Node
class_name NexusAnimationController

## Professional Godot 4.3 AnimationTree + StateMachine Controller for Project Nexus
## Drives smooth transitions across Idle, Locomotion (BlendSpace1D), Jump/Fall/Land,
## Crouch, Combat (Punch/Kick/Block/Aim), Interact, Vehicle (Enter/Drive/Exit), Hit & Death.

var anim_player: AnimationPlayer
var anim_tree: AnimationTree
var state_machine: AnimationNodeStateMachinePlayback

var current_state: String = "Locomotion"
var blend_speed: float = 0.0
var is_crouching: bool = false
var is_in_vehicle: bool = false
var is_dead: bool = false
var _action_lock_timer: float = 0.0


func setup(model_root: Node) -> void:
	anim_player = _find_animation_player(model_root)
	if anim_player == null:
		push_warning("NexusAnimationController: No AnimationPlayer found in character model.")
		return

	# Ensure looping animations are configured to loop cleanly in Godot 4.3
	var loop_anims := [
		"Idle_Breathing", "Idle_LookAround", "Walk", "Walk_Fast", "Jog",
		"Run", "Sprint", "Walk_Backward", "Strafe_Left", "Strafe_Right",
		"Jump_Air", "Fall", "Crouch_Idle", "Crouch_Walk", "Vehicle_Drive",
		"Combat_Block", "Combat_Aim", "Phone_Use", "Talk_Gesture"
	]
	for a_name in loop_anims:
		if anim_player.has_animation(a_name):
			anim_player.get_animation(a_name).loop_mode = Animation.LOOP_LINEAR

	# Build AnimationTree with AnimationNodeStateMachine + BlendSpace1D
	anim_tree = AnimationTree.new()
	anim_tree.name = "NexusAnimationTree"
	model_root.add_child(anim_tree)
	anim_tree.anim_player = anim_tree.get_path_to(anim_player)

	var sm := AnimationNodeStateMachine.new()

	# 1. Locomotion BlendSpace1D (0.0 = Idle -> 0.25 = Walk -> 0.55 = Jog -> 0.80 = Run -> 1.0 = Sprint)
	var loco_bs := AnimationNodeBlendSpace1D.new()
	loco_bs.min_space = 0.0
	loco_bs.max_space = 1.0
	_add_bs_point(loco_bs, "Idle_Breathing", 0.0)
	_add_bs_point(loco_bs, "Walk", 0.25)
	_add_bs_point(loco_bs, "Jog", 0.52)
	_add_bs_point(loco_bs, "Run", 0.78)
	_add_bs_point(loco_bs, "Sprint", 1.0)
	sm.add_node("Locomotion", loco_bs, Vector2(0, 0))

	# 2. Crouch BlendSpace1D (0.0 = Crouch_Idle -> 1.0 = Crouch_Walk)
	var crouch_bs := AnimationNodeBlendSpace1D.new()
	crouch_bs.min_space = 0.0
	crouch_bs.max_space = 1.0
	_add_bs_point(crouch_bs, "Crouch_Idle", 0.0)
	_add_bs_point(crouch_bs, "Crouch_Walk", 1.0)
	sm.add_node("Crouch", crouch_bs, Vector2(0, 120))

	# 3. Discrete Action & Airborne States
	var discrete_states := [
		"Jump_Start", "Jump_Air", "Fall", "Land",
		"Combat_Punch", "Combat_Kick", "Combat_Block", "Combat_Aim",
		"Interact_Use", "Phone_Use", "Talk_Gesture",
		"Vehicle_Enter", "Vehicle_Drive", "Vehicle_Exit",
		"Hit_React", "Death"
	]
	var pos_y := -120
	for s_name in discrete_states:
		if anim_player.has_animation(s_name):
			var node := AnimationNodeAnimation.new()
			node.animation = s_name
			sm.add_node(s_name, node, Vector2(220, pos_y))
			pos_y += 38

	# Wire Start -> Locomotion
	var start_tr := AnimationNodeStateMachineTransition.new()
	start_tr.advance_mode = AnimationNodeStateMachineTransition.ADVANCE_MODE_AUTO
	sm.add_transition("Start", "Locomotion", start_tr)

	# Wire smooth crossfade transitions between Locomotion/Crouch and all states
	var all_states := ["Locomotion", "Crouch"] + discrete_states
	for a in ["Locomotion", "Crouch"]:
		for b in all_states:
			if a != b and sm.has_node(a) and sm.has_node(b):
				_connect_xfade(sm, a, b, 0.16)
				_connect_xfade(sm, b, a, 0.18)

	# Airborne chain transitions
	_connect_xfade(sm, "Jump_Start", "Jump_Air", 0.12)
	_connect_xfade(sm, "Jump_Air", "Fall", 0.16)
	_connect_xfade(sm, "Fall", "Land", 0.10)
	_connect_xfade(sm, "Land", "Locomotion", 0.18)
	_connect_xfade(sm, "Vehicle_Enter", "Vehicle_Drive", 0.20)
	_connect_xfade(sm, "Vehicle_Drive", "Vehicle_Exit", 0.20)

	anim_tree.tree_root = sm
	anim_tree.active = true
	state_machine = anim_tree.get("parameters/playback") as AnimationNodeStateMachinePlayback
	if state_machine:
		state_machine.travel("Locomotion")


func _add_bs_point(bs: AnimationNodeBlendSpace1D, anim_name: String, pos: float) -> void:
	if anim_player.has_animation(anim_name):
		var an := AnimationNodeAnimation.new()
		an.animation = anim_name
		bs.add_blend_point(an, pos)


func _connect_xfade(sm: AnimationNodeStateMachine, from_s: String, to_s: String, xfade: float) -> void:
	if sm.has_node(from_s) and sm.has_node(to_s) and not sm.has_transition(from_s, to_s):
		var tr := AnimationNodeStateMachineTransition.new()
		tr.xfade_time = xfade
		sm.add_transition(from_s, to_s, tr)


func update_movement(delta: float, speed_ratio: float, on_floor: bool, vy: float, crouching: bool) -> void:
	if anim_tree == null or state_machine == null or is_dead:
		return

	if _action_lock_timer > 0.0:
		_action_lock_timer = max(0.0, _action_lock_timer - delta)
		return

	if is_in_vehicle:
		_travel("Vehicle_Drive")
		return

	blend_speed = lerpf(blend_speed, clampf(speed_ratio, 0.0, 1.0), minf(1.0, delta * 10.0))
	is_crouching = crouching

	if not on_floor:
		if vy > 1.2:
			_travel("Jump_Air")
		else:
			_travel("Fall")
		return

	if current_state == "Fall" or current_state == "Jump_Air":
		_travel("Land")
		_action_lock_timer = 0.22
		return

	if crouching:
		anim_tree.set("parameters/Crouch/blend_position", clampf(blend_speed * 2.2, 0.0, 1.0))
		_travel("Crouch")
	else:
		anim_tree.set("parameters/Locomotion/blend_position", blend_speed)
		_travel("Locomotion")


func trigger_action(action_state: String, lock_duration: float = 0.45) -> void:
	if state_machine == null or is_dead:
		return
	_travel(action_state)
	_action_lock_timer = lock_duration


func trigger_death() -> void:
	is_dead = true
	if state_machine:
		_travel("Death")


func revive() -> void:
	is_dead = false
	_action_lock_timer = 0.0
	if state_machine:
		_travel("Locomotion")


func set_vehicle_mode(in_vehicle: bool) -> void:
	is_in_vehicle = in_vehicle
	if in_vehicle:
		_travel("Vehicle_Drive")
	else:
		_travel("Locomotion")


func _travel(target: String) -> void:
	if current_state == target or state_machine == null:
		return
	var sm := anim_tree.tree_root as AnimationNodeStateMachine
	if sm and sm.has_node(target):
		state_machine.travel(target)
		current_state = target


func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null
