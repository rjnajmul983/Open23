extends CharacterBody3D
class_name NexusPlayerController

## Complete Third-Person Open-World Player Controller for Android Touch + Keyboard
## Integrates Kairo Vance rigged GLB, AnimationTree controller, combat, vehicle entry/exit, and camera spring-arm.

const WALK_SPEED := 3.4
const RUN_SPEED := 6.4
const SPRINT_SPEED := 9.2
const CROUCH_SPEED := 2.2
const JUMP_VELOCITY := 6.2
const GRAVITY := 18.0

var health: float = 100.0
var max_health: float = 100.0
var is_crouching: bool = false
var is_sprinting: bool = false
var is_aiming: bool = false
var is_in_vehicle: bool = false
var current_vehicle: Node3D = null

# Mobile virtual inputs set by MobileHUD
var move_input: Vector2 = Vector2.ZERO
var camera_yaw: float = 0.0
var camera_pitch: float = -0.26
var camera_sensitivity: float = 0.0048

var _step_timer: float = 0.0
var _attack_cooldown: float = 0.0
var _combo_step: int = 0

var model_root: Node3D
var anim_ctrl: NexusAnimationController
var cam_pivot: Node3D
var spring_arm: SpringArm3D
var camera: Camera3D


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1 | 4 | 8

	# Capsule collider matching Kairo Vance height (1.80m)
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.78
	col.shape = cap
	col.position = Vector3(0, 0.89, 0)
	add_child(col)

	# Load organic rigged protagonist GLB
	var scene_res := load("res://assets/characters/protagonist_kairo.glb")
	if scene_res:
		model_root = scene_res.instantiate()
		add_child(model_root)
		anim_ctrl = NexusAnimationController.new()
		add_child(anim_ctrl)
		anim_ctrl.setup(model_root)

	# Third-person spring-arm camera rig
	cam_pivot = Node3D.new()
	cam_pivot.name = "CameraPivot"
	cam_pivot.position = Vector3(0, 1.52, 0)
	add_child(cam_pivot)

	spring_arm = SpringArm3D.new()
	spring_arm.spring_length = 4.6
	spring_arm.collision_mask = 1
	spring_arm.margin = 0.25
	cam_pivot.add_child(spring_arm)

	camera = Camera3D.new()
	camera.fov = 66.0
	camera.near = 0.1
	camera.far = 320.0
	camera.current = true
	spring_arm.add_child(camera)

	GameManager.player = self
	GameManager.health_changed.emit(health, max_health)


func _physics_process(delta: float) -> void:
	if _attack_cooldown > 0.0:
		_attack_cooldown = maxf(0.0, _attack_cooldown - delta)

	# Update camera pivot orientation
	cam_pivot.rotation.y = camera_yaw
	cam_pivot.rotation.x = clampf(camera_pitch, -0.95, 0.45)

	if is_in_vehicle and current_vehicle and is_instance_valid(current_vehicle):
		global_position = current_vehicle.global_position + Vector3(0, 0.25, 0)
		spring_arm.spring_length = lerpf(spring_arm.spring_length, 7.2, delta * 5.0)
		return

	spring_arm.spring_length = lerpf(spring_arm.spring_length, 2.8 if is_aiming else 4.6, delta * 7.0)

	# Combine mobile joystick + keyboard fallback (for testing)
	var inp := move_input
	if inp.length_squared() < 0.01:
		var kx := Input.get_axis("ui_left", "ui_right")
		var ky := Input.get_axis("ui_up", "ui_down")
		inp = Vector2(kx, ky)
	if inp.length() > 1.0:
		inp = inp.normalized()

	# Gravity
	if not is_on_floor():
		velocity.y -= GRAVITY * delta

	# Camera-relative world movement direction
	var cam_basis := Basis(Vector3.UP, camera_yaw)
	var forward := -cam_basis.z
	var right := cam_basis.x
	var wish_dir := (right * inp.x - forward * inp.y)
	wish_dir.y = 0.0
	var mag := clampf(wish_dir.length(), 0.0, 1.0)
	if mag > 0.05:
		wish_dir = wish_dir.normalized()

	var target_speed := 0.0
	if mag > 0.05:
		if is_crouching:
			target_speed = CROUCH_SPEED * mag
		elif is_sprinting:
			target_speed = SPRINT_SPEED * mag
		elif mag > 0.72:
			target_speed = RUN_SPEED * mag
		else:
			target_speed = WALK_SPEED * mag

		# Smoothly face movement direction (+Z forward of character GLB)
		var target_yaw := atan2(wish_dir.x, wish_dir.z)
		if model_root:
			model_root.rotation.y = lerp_angle(model_root.rotation.y, target_yaw, minf(1.0, delta * 11.0))

	var horiz := Vector3(velocity.x, 0.0, velocity.z)
	var desired := wish_dir * target_speed
	horiz = horiz.move_toward(desired, (26.0 if is_on_floor() else 8.0) * delta)
	velocity.x = horiz.x
	velocity.z = horiz.z

	var was_airborne := not is_on_floor()
	move_and_slide()

	if was_airborne and is_on_floor():
		AudioManager.play_3d("land", global_position, -4.0)

	# Footstep audio synced to stride speed
	var spd := Vector2(velocity.x, velocity.z).length()
	if is_on_floor() and spd > 0.8:
		_step_timer -= delta * (spd / 3.4)
		if _step_timer <= 0.0:
			_step_timer = 0.44
			AudioManager.play_3d("footstep", global_position, -10.0, randf_range(0.92, 1.08))
	else:
		_step_timer = 0.1

	# Drive AnimationTree State Machine
	if anim_ctrl:
		var ratio := clampf(spd / SPRINT_SPEED, 0.0, 1.0)
		anim_ctrl.update_movement(delta, ratio, is_on_floor(), velocity.y, is_crouching)


func rotate_camera(dx: float, dy: float) -> void:
	camera_yaw -= dx * camera_sensitivity
	camera_pitch = clampf(camera_pitch - dy * camera_sensitivity, -0.95, 0.45)


func jump() -> void:
	if is_in_vehicle or not is_on_floor():
		return
	is_crouching = false
	velocity.y = JUMP_VELOCITY
	if anim_ctrl:
		anim_ctrl.trigger_action("Jump_Start", 0.22)


func toggle_crouch() -> void:
	if is_in_vehicle:
		return
	is_crouching = not is_crouching
	if is_crouching:
		is_sprinting = false


func set_sprint(active: bool) -> void:
	is_sprinting = active
	if active:
		is_crouching = false


func trigger_attack(use_weapon: bool = false) -> void:
	if is_in_vehicle or _attack_cooldown > 0.0:
		return

	if use_weapon:
		_attack_cooldown = 0.32
		if anim_ctrl:
			anim_ctrl.trigger_action("Combat_Aim", 0.35)
		AudioManager.play_3d("gunshot", global_position + Vector3(0, 1.4, 0), -1.0, randf_range(0.95, 1.05))
		_fire_weapon_raycast()
		GameManager.report_crime(2)
	else:
		_attack_cooldown = 0.46
		_combo_step = (_combo_step + 1) % 2
		var act := "Combat_Punch" if _combo_step == 0 else "Combat_Kick"
		if anim_ctrl:
			anim_ctrl.trigger_action(act, 0.42)
		AudioManager.play_3d("punch_hit", global_position + Vector3(0, 1.2, 0), -4.0)
		_perform_melee_hit()


func _perform_melee_hit() -> void:
	var fwd := Vector3(sin(model_root.rotation.y), 0.0, cos(model_root.rotation.y)) if model_root else -cam_pivot.global_basis.z
	for npc in GameManager.active_pedestrians + GameManager.active_police:
		if not is_instance_valid(npc):
			continue
		var diff := npc.global_position - global_position
		if diff.length() < 2.3 and diff.normalized().dot(fwd) > 0.25:
			if npc.has_method("take_damage"):
				npc.take_damage(34.0, self)
			GameManager.report_crime(1)
			break


func _fire_weapon_raycast() -> void:
	var space := get_world_3d().direct_space_state
	var origin := camera.global_position
	var end := origin - camera.global_basis.z * 65.0
	var q := PhysicsRayQueryParameters3D.create(origin, end)
	q.exclude = [get_rid()]
	var hit := space.intersect_ray(q)
	if hit and hit.collider and hit.collider.has_method("take_damage"):
		hit.collider.take_damage(52.0, self)


func interact_or_toggle_vehicle() -> void:
	if is_in_vehicle and current_vehicle:
		exit_vehicle()
		return

	# Check nearby vehicles first (within 4.8m)
	var nearest_v: Node3D = null
	var best_d := 4.8
	for v in GameManager.active_vehicles:
		if is_instance_valid(v):
			var d := global_position.distance_to(v.global_position)
			if d < best_d:
				best_d = d
				nearest_v = v

	if nearest_v != null:
		enter_vehicle(nearest_v)
		return

	# Otherwise trigger general interaction animation & check mission/NPC interaction
	if anim_ctrl:
		anim_ctrl.trigger_action("Interact_Use", 0.55)
	AudioManager.play_ui("ui_click")
	MissionManager.try_interact(global_position)


func enter_vehicle(vehicle: Node3D) -> void:
	is_in_vehicle = true
	current_vehicle = vehicle
	visible = false
	set_collision_layer_value(2, false)
	if vehicle.has_method("set_driver"):
		vehicle.set_driver(self)
	if anim_ctrl:
		anim_ctrl.set_vehicle_mode(true)
	GameManager.current_vehicle = vehicle
	GameManager.vehicle_state_changed.emit(true, vehicle)


func exit_vehicle() -> void:
	if not is_in_vehicle or current_vehicle == null:
		return
	var exit_pos := current_vehicle.global_position + current_vehicle.global_basis.x * 2.4 + Vector3(0, 0.35, 0)
	if current_vehicle.has_method("set_driver"):
		current_vehicle.set_driver(null)
	is_in_vehicle = false
	current_vehicle = null
	global_position = exit_pos
	visible = true
	set_collision_layer_value(2, true)
	if anim_ctrl:
		anim_ctrl.set_vehicle_mode(false)
	GameManager.current_vehicle = null
	GameManager.vehicle_state_changed.emit(false, null)


func take_damage(amount: float, _attacker: Node = null) -> void:
	if health <= 0.0:
		return
	health = maxf(0.0, health - amount)
	GameManager.health_changed.emit(health, max_health)
	if anim_ctrl:
		if health <= 0.0:
			anim_ctrl.trigger_death()
			GameManager.post_notification("WASTED", "Respawning at Harborview Medical Center...")
			await get_tree().create_timer(3.0).timeout
			_respawn()
		else:
			anim_ctrl.trigger_action("Hit_React", 0.35)


func _respawn() -> void:
	if is_in_vehicle:
		exit_vehicle()
	health = max_health
	global_position = Vector3(12.0, 1.0, 12.0)
	GameManager.set_wanted_level(0)
	GameManager.health_changed.emit(health, max_health)
	if anim_ctrl:
		anim_ctrl.revive()


func get_health() -> float:
	return health


func set_health(val: float) -> void:
	health = clampf(val, 1.0, max_health)
	GameManager.health_changed.emit(health, max_health)
