extends CanvasLayer
class_name NexusMobileHUD

## Professional Responsive Android Touchscreen UI for Project Nexus
## Features floating virtual joystick, multi-touch camera drag, contextual On-Foot & Driving buttons,
## live 2D Minimap, Health/Wanted/Money/Mission HUD, Notification Toast, and Settings/Save/Load Modal.

var player: NexusPlayerController
var day_night: NexusDayNightWeather

# Virtual Joystick State
var _joy_touch_id: int = -1
var _cam_touch_id: int = -1
var _joy_origin: Vector2 = Vector2(140, 560)
var _joy_radius: float = 78.0
var _joy_knob_pos: Vector2 = Vector2(140, 560)

# Driving hold flags
var _gas_held: bool = false
var _brake_held: bool = false
var _steer_l_held: bool = false
var _steer_r_held: bool = false

# UI Nodes
var joy_draw: Control
var minimap_draw: Control
var hp_bar: ProgressBar
var money_lbl: Label
var wanted_lbl: Label
var mission_lbl: Label
var notif_panel: PanelContainer
var notif_lbl: Label
var _notif_timer: float = 0.0

var onfoot_group: Control
var driving_group: Control
var settings_modal: PanelContainer


func bind_world(p: NexusPlayerController, dn: NexusDayNightWeather) -> void:
	player = p
	day_night = dn


func _ready() -> void:
	_build_hud()
	GameManager.health_changed.connect(_on_health)
	GameManager.money_changed.connect(_on_money)
	GameManager.wanted_level_changed.connect(_on_wanted)
	GameManager.notification_posted.connect(_on_notify)
	GameManager.vehicle_state_changed.connect(_on_vehicle_mode)
	MissionManager.mission_updated.connect(_on_mission)

	_on_money(GameManager.money)
	_on_wanted(GameManager.wanted_level)


func _build_hud() -> void:
	# 1. Custom Canvas for Virtual Joystick visualization
	joy_draw = Control.new()
	joy_draw.set_anchors_preset(Control.PRESET_FULL_RECT)
	joy_draw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joy_draw.draw.connect(_draw_joystick)
	add_child(joy_draw)

	# 2. Live 2D Minimap (Top-Left)
	var map_frame := PanelContainer.new()
	map_frame.position = Vector2(18, 18)
	map_frame.size = Vector2(158, 158)
	add_child(map_frame)

	minimap_draw = Control.new()
	minimap_draw.custom_minimum_size = Vector2(150, 150)
	minimap_draw.draw.connect(_draw_minimap)
	map_frame.add_child(minimap_draw)

	# 3. Top-Right Status Cluster (Health, Money, Wanted Stars, Menu)
	var top_r := VBoxContainer.new()
	top_r.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	top_r.offset_left = -280
	top_r.offset_top = 16
	top_r.offset_right = -16
	top_r.offset_bottom = 170
	add_child(top_r)

	var hrow := HBoxContainer.new()
	top_r.add_child(hrow)

	money_lbl = Label.new()
	money_lbl.text = "$500"
	money_lbl.add_theme_font_size_override("font_size", 22)
	money_lbl.add_theme_color_override("font_color", Color(0.32, 0.94, 0.48))
	money_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hrow.add_child(money_lbl)

	var menu_btn := _make_btn("MENU", Vector2(78, 38), Color(0.15, 0.19, 0.28, 0.85))
	menu_btn.pressed.connect(func(): settings_modal.visible = not settings_modal.visible; AudioManager.play_ui("ui_click"))
	hrow.add_child(menu_btn)

	hp_bar = ProgressBar.new()
	hp_bar.min_value = 0
	hp_bar.max_value = 100
	hp_bar.value = 100
	hp_bar.custom_minimum_size = Vector2(240, 20)
	top_r.add_child(hp_bar)

	wanted_lbl = Label.new()
	wanted_lbl.text = "☆☆☆☆☆"
	wanted_lbl.add_theme_font_size_override("font_size", 20)
	wanted_lbl.add_theme_color_override("font_color", Color(1.0, 0.82, 0.16))
	top_r.add_child(wanted_lbl)

	# 4. Mission Objective Banner (Top-Center)
	mission_lbl = Label.new()
	mission_lbl.set_anchors_preset(Control.PRESET_TOP_WIDE)
	mission_lbl.offset_left = 200
	mission_lbl.offset_right = -300
	mission_lbl.offset_top = 16
	mission_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mission_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_lbl.add_theme_font_size_override("font_size", 16)
	mission_lbl.add_theme_color_override("font_color", Color(0.98, 0.96, 0.88))
	add_child(mission_lbl)

	# 5. Toast Notification Panel
	notif_panel = PanelContainer.new()
	notif_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	notif_panel.offset_left = -220
	notif_panel.offset_right = 220
	notif_panel.offset_top = 74
	notif_panel.visible = false
	add_child(notif_panel)

	notif_lbl = Label.new()
	notif_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	notif_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notif_lbl.add_theme_font_size_override("font_size", 15)
	notif_panel.add_child(notif_lbl)

	# 6. ON-FOOT ACTION BUTTONS (Bottom-Right)
	onfoot_group = Control.new()
	onfoot_group.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	onfoot_group.offset_left = -360
	onfoot_group.offset_top = -280
	onfoot_group.offset_right = -16
	onfoot_group.offset_bottom = -16
	add_child(onfoot_group)

	var b_jump := _make_btn("JUMP", Vector2(78, 56), Color(0.18, 0.45, 0.82, 0.82))
	b_jump.position = Vector2(258, 130)
	b_jump.pressed.connect(func(): if player: player.jump())
	onfoot_group.add_child(b_jump)

	var b_sprint := _make_btn("SPRINT", Vector2(78, 52), Color(0.20, 0.62, 0.44, 0.82))
	b_sprint.position = Vector2(258, 66)
	b_sprint.button_down.connect(func(): if player: player.set_sprint(true))
	b_sprint.button_up.connect(func(): if player: player.set_sprint(false))
	onfoot_group.add_child(b_sprint)

	var b_crouch := _make_btn("CROUCH", Vector2(78, 48), Color(0.32, 0.36, 0.44, 0.82))
	b_crouch.position = Vector2(170, 200)
	b_crouch.pressed.connect(func(): if player: player.toggle_crouch())
	onfoot_group.add_child(b_crouch)

	var b_punch := _make_btn("FIGHT", Vector2(82, 62), Color(0.84, 0.28, 0.18, 0.86))
	b_punch.position = Vector2(166, 126)
	b_punch.pressed.connect(func(): if player: player.trigger_attack(false))
	onfoot_group.add_child(b_punch)

	var b_shoot := _make_btn("FIRE", Vector2(78, 52), Color(0.92, 0.48, 0.12, 0.86))
	b_shoot.position = Vector2(170, 66)
	b_shoot.pressed.connect(func(): if player: player.trigger_attack(true))
	onfoot_group.add_child(b_shoot)

	var b_use := _make_btn("CAR / USE", Vector2(106, 52), Color(0.92, 0.68, 0.12, 0.88))
	b_use.position = Vector2(230, 4)
	b_use.pressed.connect(func(): if player: player.interact_or_toggle_vehicle())
	onfoot_group.add_child(b_use)

	# 7. DRIVING CONTROLS (Shown only while inside a vehicle)
	driving_group = Control.new()
	driving_group.set_anchors_preset(Control.PRESET_FULL_RECT)
	driving_group.mouse_filter = Control.MOUSE_FILTER_IGNORE
	driving_group.visible = false
	add_child(driving_group)

	var steer_l := _make_btn("◀", Vector2(92, 74), Color(0.16, 0.22, 0.34, 0.84))
	steer_l.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	steer_l.position = Vector2(28, -110)
	steer_l.button_down.connect(func(): _steer_l_held = true)
	steer_l.button_up.connect(func(): _steer_l_held = false)
	driving_group.add_child(steer_l)

	var steer_r := _make_btn("▶", Vector2(92, 74), Color(0.16, 0.22, 0.34, 0.84))
	steer_r.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	steer_r.position = Vector2(138, -110)
	steer_r.button_down.connect(func(): _steer_r_held = true)
	steer_r.button_up.connect(func(): _steer_r_held = false)
	driving_group.add_child(steer_r)

	var gas_btn := _make_btn("GAS", Vector2(96, 86), Color(0.18, 0.72, 0.34, 0.86))
	gas_btn.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	gas_btn.position = Vector2(-120, -120)
	gas_btn.button_down.connect(func(): _gas_held = true)
	gas_btn.button_up.connect(func(): _gas_held = false)
	driving_group.add_child(gas_btn)

	var brk_btn := _make_btn("BRAKE", Vector2(96, 72), Color(0.84, 0.22, 0.22, 0.86))
	brk_btn.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	brk_btn.position = Vector2(-232, -106)
	brk_btn.button_down.connect(func(): _brake_held = true)
	brk_btn.button_up.connect(func(): _brake_held = false)
	driving_group.add_child(brk_btn)

	var horn_btn := _make_btn("HORN", Vector2(82, 48), Color(0.82, 0.62, 0.14, 0.85))
	horn_btn.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	horn_btn.position = Vector2(-224, -172)
	horn_btn.pressed.connect(func(): if GameManager.current_vehicle: GameManager.current_vehicle.honk_horn())
	driving_group.add_child(horn_btn)

	var exit_btn := _make_btn("EXIT CAR", Vector2(106, 52), Color(0.92, 0.45, 0.14, 0.88))
	exit_btn.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	exit_btn.position = Vector2(-126, -184)
	exit_btn.pressed.connect(func(): if player: player.exit_vehicle())
	driving_group.add_child(exit_btn)

	# 8. SETTINGS / SAVE / LOAD / GRAPHICS / WEATHER MODAL
	_build_settings_modal()


func _build_settings_modal() -> void:
	settings_modal = PanelContainer.new()
	settings_modal.set_anchors_preset(Control.PRESET_CENTER)
	settings_modal.offset_left = -190
	settings_modal.offset_right = 190
	settings_modal.offset_top = -185
	settings_modal.offset_bottom = 185
	settings_modal.visible = false
	add_child(settings_modal)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	settings_modal.add_child(vb)

	var ttl := Label.new()
	ttl.text = "PROJECT NEXUS — MENU"
	ttl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ttl.add_theme_font_size_override("font_size", 20)
	vb.add_child(ttl)

	var b_save := _make_btn("Save Game Progress", Vector2(320, 42), Color(0.18, 0.56, 0.34, 0.92))
	b_save.pressed.connect(func(): SaveManager.save_game(); settings_modal.visible = false)
	vb.add_child(b_save)

	var b_load := _make_btn("Load Saved Game", Vector2(320, 42), Color(0.20, 0.42, 0.72, 0.92))
	b_load.pressed.connect(func(): SaveManager.load_game(); settings_modal.visible = false)
	vb.add_child(b_load)

	var gfx_row := HBoxContainer.new()
	vb.add_child(gfx_row)
	for g_idx in range(3):
		var names := ["GFX: LOW", "GFX: MED", "GFX: HIGH"]
		var gb := _make_btn(names[g_idx], Vector2(104, 38), Color(0.28, 0.32, 0.40, 0.92))
		gb.pressed.connect(func(): GameManager.set_graphics_quality(g_idx); GameManager.post_notification("GRAPHICS", "Quality set to " + names[g_idx]))
		gfx_row.add_child(gb)

	var wx_row := HBoxContainer.new()
	vb.add_child(wx_row)
	for wx in ["Clear", "Overcast", "Rain"]:
		var wb := _make_btn(wx, Vector2(104, 38), Color(0.24, 0.38, 0.52, 0.92))
		wb.pressed.connect(func(): if day_night: day_night.set_weather(wx))
		wx_row.add_child(wb)

	var b_close := _make_btn("Resume Game", Vector2(320, 42), Color(0.75, 0.26, 0.20, 0.92))
	b_close.pressed.connect(func(): settings_modal.visible = false)
	vb.add_child(b_close)


func _make_btn(label_txt: String, sz: Vector2, bg: Color) -> Button:
	var b := Button.new()
	b.text = label_txt
	b.custom_minimum_size = sz
	b.size = sz
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.corner_radius_top_left = 14
	sb.corner_radius_top_right = 14
	sb.corner_radius_bottom_left = 14
	sb.corner_radius_bottom_right = 14
	sb.border_width_bottom = 2
	sb.border_color = Color(1, 1, 1, 0.28)
	b.add_theme_stylebox_override("normal", sb)
	return b


func _input(event: InputEvent) -> void:
	if settings_modal and settings_modal.visible:
		return
	var vp_w := get_viewport().get_visible_rect().size.x

	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			if t.position.x < vp_w * 0.42 and _joy_touch_id == -1 and not driving_group.visible:
				_joy_touch_id = t.index
				_joy_origin = t.position
				_joy_knob_pos = t.position
			elif t.position.x >= vp_w * 0.42 and _cam_touch_id == -1:
				_cam_touch_id = t.index
		else:
			if t.index == _joy_touch_id:
				_joy_touch_id = -1
				_joy_knob_pos = _joy_origin
				if player:
					player.move_input = Vector2.ZERO
			elif t.index == _cam_touch_id:
				_cam_touch_id = -1

	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == _joy_touch_id and player and not driving_group.visible:
			var delta_v := d.position - _joy_origin
			if delta_v.length() > _joy_radius:
				delta_v = delta_v.normalized() * _joy_radius
			_joy_knob_pos = _joy_origin + delta_v
			player.move_input = delta_v / _joy_radius
		elif d.index == _cam_touch_id and player:
			player.rotate_camera(d.relative.x, d.relative.y)


func _process(delta: float) -> void:
	# Drive active vehicle from touchscreen pedals
	if driving_group.visible and GameManager.current_vehicle and is_instance_valid(GameManager.current_vehicle):
		var v := GameManager.current_vehicle as NexusVehicleController
		if v:
			v.throttle_input = (1.0 if _gas_held else 0.0) - (1.0 if _brake_held else 0.0)
			v.steer_input = (1.0 if _steer_r_held else 0.0) - (1.0 if _steer_l_held else 0.0)

	if _notif_timer > 0.0:
		_notif_timer -= delta
		if _notif_timer <= 0.0:
			notif_panel.visible = false

	joy_draw.queue_redraw()
	minimap_draw.queue_redraw()


func _draw_joystick() -> void:
	if driving_group.visible:
		return
	var base_p := _joy_origin if _joy_touch_id != -1 else Vector2(128, get_viewport().get_visible_rect().size.y - 128)
	var knob_p := _joy_knob_pos if _joy_touch_id != -1 else base_p
	joy_draw.draw_circle(base_p, _joy_radius, Color(0.08, 0.12, 0.18, 0.42))
	joy_draw.draw_arc(base_p, _joy_radius, 0.0, TAU, 32, Color(1.0, 1.0, 1.0, 0.45), 2.5)
	joy_draw.draw_circle(knob_p, 30.0, Color(0.95, 0.72, 0.18, 0.78))


func _draw_minimap() -> void:
	var sz := minimap_draw.size
	var center := sz * 0.5
	minimap_draw.draw_rect(Rect2(Vector2.ZERO, sz), Color(0.08, 0.11, 0.16, 0.90))
	if player == null or not is_instance_valid(player):
		return

	var scale_m := 0.65
	var ppos := player.global_position

	# Draw road grid lines relative to player
	for rc in [-128.0, -64.0, 0.0, 64.0, 128.0]:
		var rx := center.x + (rc - ppos.x) * scale_m
		var rz := center.y + (rc - ppos.z) * scale_m
		if rx >= 0 and rx <= sz.x:
			minimap_draw.draw_line(Vector2(rx, 0), Vector2(rx, sz.y), Color(0.28, 0.32, 0.38), 5.0)
		if rz >= 0 and rz <= sz.y:
			minimap_draw.draw_line(Vector2(0, rz), Vector2(sz.x, rz), Color(0.28, 0.32, 0.38), 5.0)

	# Vehicles (cyan dots)
	for v in GameManager.active_vehicles:
		if is_instance_valid(v):
			var mp := center + Vector2(v.global_position.x - ppos.x, v.global_position.z - ppos.z) * scale_m
			if Rect2(Vector2.ZERO, sz).has_point(mp):
				minimap_draw.draw_circle(mp, 3.0, Color(0.25, 0.85, 0.98))

	# Police (flashing red/blue dots)
	for cop in GameManager.active_police:
		if is_instance_valid(cop):
			var mp := center + Vector2(cop.global_position.x - ppos.x, cop.global_position.z - ppos.z) * scale_m
			if Rect2(Vector2.ZERO, sz).has_point(mp):
				minimap_draw.draw_circle(mp, 3.5, Color(1.0, 0.2, 0.25))

	# Active Mission Blip (yellow beacon clamped to border)
	if MissionManager.has_active_mission:
		var m_off := Vector2(MissionManager.active_target_pos.x - ppos.x, MissionManager.active_target_pos.z - ppos.z) * scale_m
		if m_off.length() > sz.x * 0.44:
			m_off = m_off.normalized() * (sz.x * 0.44)
		minimap_draw.draw_circle(center + m_off, 5.5, Color(1.0, 0.82, 0.12))

	# Player Marker (center)
	minimap_draw.draw_circle(center, 4.5, Color(0.25, 1.0, 0.45))


func _on_health(cur: float, _mx: float) -> void:
	if hp_bar:
		hp_bar.value = cur


func _on_money(val: int) -> void:
	if money_lbl:
		money_lbl.text = "$%d" % val


func _on_wanted(lvl: int) -> void:
	if wanted_lbl:
		var s := ""
		for i in range(5):
			s += "★" if i < lvl else "☆"
		wanted_lbl.text = s


func _on_mission(title: String, obj: String, _target: Vector3) -> void:
	if mission_lbl:
		mission_lbl.text = "%s\n%s" % [title, obj]


func _on_notify(title: String, msg: String) -> void:
	if notif_panel and notif_lbl:
		notif_lbl.text = "%s — %s" % [title, msg]
		notif_panel.visible = true
		_notif_timer = 4.2


func _on_vehicle_mode(in_veh: bool, _ref: Node) -> void:
	onfoot_group.visible = not in_veh
	driving_group.visible = in_veh
	_gas_held = false
	_brake_held = false
	_steer_l_held = false
	_steer_r_held = false
