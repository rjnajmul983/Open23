extends Node

## Persistent JSON Save & Load System for Android (user://project_nexus_save.json)

const SAVE_PATH := "user://project_nexus_save.json"


func save_game() -> bool:
	var data := {
		"version": "1.0.0",
		"money": GameManager.money,
		"respect": GameManager.respect,
		"wanted_level": GameManager.wanted_level,
		"time_of_day": GameManager.time_of_day,
		"weather_mode": GameManager.weather_mode,
		"graphics_quality": GameManager.graphics_quality,
		"mission_index": MissionManager.current_mission_index,
		"completed_missions": MissionManager.completed_missions,
		"player_pos": [0.0, 1.0, 0.0],
		"player_health": 100.0,
	}
	if GameManager.player and is_instance_valid(GameManager.player):
		var p := GameManager.player.global_position
		data["player_pos"] = [p.x, p.y, p.z]
		if GameManager.player.has_method("get_health"):
			data["player_health"] = GameManager.player.get_health()

	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		GameManager.post_notification("SAVE ERROR", "Could not write save file.")
		return false
	f.store_string(JSON.stringify(data, "  "))
	f.close()
	GameManager.post_notification("GAME SAVED", "Progress saved to local device storage.")
	return true


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		GameManager.post_notification("NO SAVE FOUND", "Start playing and tap Save first.")
		return false
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return false

	GameManager.money = int(parsed.get("money", 500))
	GameManager.money_changed.emit(GameManager.money)
	GameManager.respect = int(parsed.get("respect", 0))
	GameManager.set_wanted_level(int(parsed.get("wanted_level", 0)))
	GameManager.time_of_day = float(parsed.get("time_of_day", 10.5))
	GameManager.weather_mode = str(parsed.get("weather_mode", "Clear"))
	GameManager.set_graphics_quality(int(parsed.get("graphics_quality", 1)))

	if GameManager.player and is_instance_valid(GameManager.player):
		var pos_arr: Array = parsed.get("player_pos", [0.0, 1.0, 0.0])
		if pos_arr.size() == 3:
			GameManager.player.global_position = Vector3(float(pos_arr[0]), float(pos_arr[1]) + 0.3, float(pos_arr[2]))
		if GameManager.player.has_method("set_health"):
			GameManager.player.set_health(float(parsed.get("player_health", 100.0)))

	var m_idx := int(parsed.get("mission_index", 0))
	MissionManager.restore_progress(m_idx, parsed.get("completed_missions", []))
	GameManager.post_notification("GAME LOADED", "Restored saved progress.")
	return true
